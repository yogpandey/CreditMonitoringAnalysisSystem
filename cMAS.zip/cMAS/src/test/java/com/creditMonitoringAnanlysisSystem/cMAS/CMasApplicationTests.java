package com.creditMonitoringAnanlysisSystem.cMAS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CMasApplicationTests {

	@Test
	void contextLoads() {
	}

}
