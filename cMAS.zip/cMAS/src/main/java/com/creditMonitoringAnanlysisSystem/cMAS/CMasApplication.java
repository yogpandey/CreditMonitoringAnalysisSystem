package com.creditMonitoringAnanlysisSystem.cMAS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CMasApplication {

	public static void main(String[] args) {
		SpringApplication.run(CMasApplication.class, args);
	}

}
